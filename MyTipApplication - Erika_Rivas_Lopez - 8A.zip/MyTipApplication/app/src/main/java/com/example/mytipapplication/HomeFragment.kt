package com.example.mytipapplication

import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.core.widget.addTextChangedListener
import androidx.navigation.fragment.findNavController
import androidx.preference.Preference
import androidx.preference.PreferenceManager
import kotlinx.android.synthetic.main.fragment_home.*


class HomeFragment : Fragment() {

    var amount = 0
    var value = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    @RequiresApi(Build.VERSION_CODES.N)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        fab_settings.setOnClickListener {

            findNavController().navigate(R.id.action_homeFragment_to_settingsFragment)
        }

        new_amount.addTextChangedListener(object: TextWatcher{
            override fun afterTextChanged(s: Editable?) {
            }
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                var text = s.toString()
                if(text==""){
                    text = "1"
                }
                amount = Integer.parseInt(text)
                amount_spend.text = "Amount: $amount"

                calculatePercentage()
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }
        })

        settings()
    }

    @RequiresApi(Build.VERSION_CODES.N)
    private fun settings() {
        val sp = PreferenceManager.getDefaultSharedPreferences(context)
        var current = "empty"

        val percentage = sp.getInt("tipperc", 0)
        val onoff = sp.getBoolean("tiponoff", false)
        value = percentage

        if(onoff){
            current = "Not allow"
        } else{
            current = "Allow"
        }


        percent.text = "Percentage: $percentage"
       // pb_volume.setProgress(percentage, true)
        state.text = "On/Off: $current"

    }

    private fun calculatePercentage(){

        val th = amount * value/100
        val total = amount + th

        tip_value.text = "Tip value: $th"
        tip_total.text = "Total: $total"

        //total = tip_value * v;

        //tip_total
    }

}
